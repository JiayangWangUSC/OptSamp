function kernel = getKernel(GOP)

kernel = GOP.kernel;

