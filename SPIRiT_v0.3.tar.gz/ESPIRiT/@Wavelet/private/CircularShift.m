function res = CircularShift(x,sx,sy)

res = circshift(x,[sx,sy]);

