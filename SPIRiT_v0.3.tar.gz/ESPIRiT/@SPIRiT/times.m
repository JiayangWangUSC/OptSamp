function res = mtimes(a,x)
% performs the SPIRIT operator
% see mtimes


res = mtimes(a,x);

