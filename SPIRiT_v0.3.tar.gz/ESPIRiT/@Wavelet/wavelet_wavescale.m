function ws = wavelet_wavescale(w)
	ws = w.wavScale;
