disp('This script does nothing. It is used to chech if the util directory is in the path');

