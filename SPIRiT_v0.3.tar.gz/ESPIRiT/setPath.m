addpath utils
addpath ESPIRiT_code
addpath SPIRiT_code
addpath nufft_files
addpath data
addpath coilCompression_code
addpath SAKE_code


