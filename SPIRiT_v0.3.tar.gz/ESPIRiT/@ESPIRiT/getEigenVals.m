function res = getEigenVals(a)
res = a.eigenVals;
