function qmf = wavelet_qmf(w)
	qmf = w.qmf;
